-- ---------------------------------------------------------
--
-- SIMPLE SQL Dump
-- 
-- nawa (at) yahoo (dot) com
--
-- Host Connection Info: localhost via TCP/IP
-- Generation Time: March 24, 2018 at 17:29 PM ( ASIA/JAKARTA )
-- PHP Version: 7.1.1
--
-- ---------------------------------------------------------



SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;


-- ---------------------------------------------------------
--
-- Table structure for table : `surat_keputusan`
--
-- ---------------------------------------------------------

CREATE TABLE `surat_keputusan` (
  `id_sk` int(11) NOT NULL,
  `nama_sk` varchar(255) NOT NULL,
  `nomor_sk` varchar(50) NOT NULL,
  `tgl_penetapan` date NOT NULL,
  `edoc` varchar(255) NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_sk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `surat_keputusan`
--

INSERT INTO `surat_keputusan` (`id_sk`, `nama_sk`, `nomor_sk`, `tgl_penetapan`, `edoc`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'Surat Keputusan Peningkatan Kelas pada Empat Puluh Enam Pengadilan Negeri Kelas II Menjadi Kelas I B Dan Tujuh Belas Pengadilan Negeri Kelas I B Menjadi Kelas I A', '36/KMA/SK/II/2017', '2017-02-09', '1_36_KMA_SK_II_2017.pdf', 1, '2018-03-24 17:18:57', '', ''),
(2, 'Surat Keputusan Peningkatan Kelas pada Dua Puluh Sembilan Pengadilan Agama Kelas II Menjadi Kelas I B Dan Dua Puluh Satu Pengadilan Agama Kelas I B Menjadi Kelas I A', '37/KMA/SK/II/2017', '2017-02-09', '2_37_KMA_SK_II_2017.pdf', 1, '2018-03-24 17:20:17', '', ''),
(3, 'Surat Keputusan Peningkatan Kelas pada Dua Mahkamah Syar’iyah Kelas II Menjadi Kelas I B', '38/KMA/SK/II/2017', '2017-02-09', '3_38_KMA_SK_II_2017.pdf', 1, '2018-03-24 17:21:25', '', ''),
(4, 'Surat Keputusan Peningkatan Kelas Pada Tiga Pengadilan Militer Tipe B Menjadi Tipe A', '39/KMA/SK/II/2017', '2017-02-09', '4_39_KMA_SK_II_2017.pdf', 1, '2018-03-24 17:23:45', '', ''),
(5, 'Surat Keputusan Pembentukan Panitia Penyusunan dan Penyelenggaraan Laporan Tahunan 2017 Mahkamah Agung Republik Indonesia', '174/KMA/SK/IX/2017', '2017-09-28', '5_SK_LAPTAH_2017.pdf', 1, '2018-03-24 17:28:04', '', '');



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_database`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_database` (
  `id_db` int(11) NOT NULL,
  `nama_db` varchar(35) NOT NULL,
  `aksi` enum('Backup','Import') NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_db`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



-- ---------------------------------------------------------
--
-- Table structure for table : `sys_user`
--
-- ---------------------------------------------------------

CREATE TABLE `sys_user` (
  `id_user` int(11) NOT NULL,
  `nama_user` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(45) NOT NULL,
  `hak_akses` enum('Admin','User') NOT NULL,
  `blokir` enum('Ya','Tidak') NOT NULL,
  `created_user` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_user` int(11) DEFAULT NULL,
  `updated_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sys_user`
--

INSERT INTO `sys_user` (`id_user`, `nama_user`, `username`, `password`, `hak_akses`, `blokir`, `created_user`, `created_date`, `updated_user`, `updated_date`) VALUES
(1, 'Indra Styawantoro', 'admin', '0937afa17f4dc08f3c0e5dc908158370ce64df86', 'Admin', 'Tidak', 1, '2017-11-27 11:01:36', '', ''),
(2, 'Danang Kesuma', 'user', 'adcd7048512e64b48da55b027577886ee5a36350', 'User', 'Tidak', 1, '2018-01-21 03:21:01', '', '');


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;